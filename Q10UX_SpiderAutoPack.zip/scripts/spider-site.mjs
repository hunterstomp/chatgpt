// scripts/spider-site.mjs
// Crawl portfolio.q10ux.com, extract About + Case Studies, generate clean MDX.
// Images remain HOTLINKED (absolute URLs).
// Node >= 18, ESM project.
import fs from "node:fs";
import path from "node:path";
import { fetchHtml, parseHtml, ensureDir, toMarkdown, extractGallery, slugify, extractSummary, stringifyFrontmatter } from "./helpers.mjs";

const BASE = "https://portfolio.q10ux.com/";
const CASE_DIR = "src/pages/case-studies";
const PAGES_OUT = "src/pages";
const LOG_DIR = "public/assets/scrape";
ensureDir(CASE_DIR); ensureDir(PAGES_OUT); ensureDir(LOG_DIR);

const visited = new Set();
const queue = [BASE];
const pages = new Set();

function withinSite(u){ try { return new URL(u).origin === new URL(BASE).origin; } catch { return false; } }
function isHtmlPath(u){ return u.endsWith(".html") || !u.includes("."); }
function isAsset(u){ return /\.(png|jpe?g|webp|svg|gif|mp4|pdf|zip|css|js)(\?|$)/i.test(u); }

function looksCaseStudy(url){
  const u = new URL(url);
  const p = u.pathname.toLowerCase();
  return p.includes("case") || p.includes("study") || p.includes("tmobile") || p.includes("atmosfx") || p.includes("att") || p.includes("microsoft") || p.includes("bmgf") || p.includes("disney");
}

function pickSlug(url, doc){
  const u = new URL(url);
  const last = u.pathname.split("/").filter(Boolean).pop() || "case";
  if(last.endsWith(".html")) return last.replace(/\.html$/,"");
  const h1 = doc.querySelector("h1")?.textContent?.trim();
  if(h1) return slugify(h1);
  return slugify(last);
}

async function crawl(){
  while(queue.length){
    const url = queue.shift();
    if(visited.has(url)) continue;
    visited.add(url);
    let html = "";
    try { html = await fetchHtml(url); } catch { continue; }
    const doc = parseHtml(html);
    const anchors = Array.from(doc.querySelectorAll("a[href]"));
    for(const a of anchors){
      const u = a.getAttribute("href") || "";
      const abs = new URL(u, url).toString();
      if(!withinSite(abs)) continue;
      if(isAsset(abs)) continue;
      if(!visited.has(abs) && isHtmlPath(abs)){
        queue.push(abs);
        if(abs.startsWith(BASE)) pages.add(abs);
      }
    }
    if(visited.size > 400) break;
  }
}

function bodyMarkdown(doc){ return toMarkdown(doc); }
function titleOf(doc){ return (doc.querySelector("h1")?.textContent || doc.title || "").trim(); }

function makeFrontmatter({title, slug, summary, gallery, layout, status="draft", thumb}){
  const fm = { title, slug, status, summary, layout, thumb, gallery };
  return stringifyFrontmatter(fm);
}

function writeMDXCase({slug, title, summary, md, gallery}){
  const layout = "../layouts/CaseStudyLayout.astro";
  const fm = makeFrontmatter({title, slug, summary, gallery, layout});
  const out = `${fm}${md}\n`;
  const p = path.join(CASE_DIR, `${slug}.mdx`);
  fs.writeFileSync(p, out, "utf-8");
  return p;
}

function writeMDXPage({name, title, md}){
  const slug = name;
  const layout = "../layouts/BasePageLayout.astro";
  const fm = stringifyFrontmatter({ title, slug, status: "draft", layout });
  const p = path.join(PAGES_OUT, `${name}.mdx`);
  fs.writeFileSync(p, fm + md + "\n", "utf-8");
  return p;
}

function galleryThumb(gallery){
  if(!gallery?.length) return "";
  const first = gallery.find(g => g.alt || g.caption) || gallery[0];
  return first?.src || "";
}

function isAbout(url){ return /about(\.html)?$/i.test(url); }
function isHome(url){
  const u = new URL(url);
  const p = u.pathname.replace(/\/+/g,"/");
  return p === "/" || /index\.html$/i.test(p);
}
function cleanMarkdown(md){ return md.replace(/\n{3,}/g,"\n\n").trim() + "\n"; }

const scraped = [];

async function generate(){
  await crawl();
  const targets = Array.from(pages).filter(u => isAbout(u) || looksCaseStudy(u) || isHome(u));
  for(const page of targets){
    try{
      const html = await fetchHtml(page);
      const doc = parseHtml(html);
      const title = titleOf(doc);
      const slug = isAbout(page) ? "about" : isHome(page) ? "index" : pickSlug(page, doc);
      const summary = extractSummary(doc);
      const gallery = extractGallery(doc, page);
      const md = cleanMarkdown(bodyMarkdown(doc));

      if(slug === "about"){
        writeMDXPage({ name: "about", title: title || "About", md });
      } else if(slug === "index"){
        const out = path.join(PAGES_OUT, "index.mdx");
        if(!fs.existsSync(out)){
          writeMDXPage({ name: "index", title: title || "Home", md });
        }
      } else {
        const file = writeMDXCase({ slug, title: title || slug, summary, md, gallery });
        scraped.push({ slug, title, summary, galleryCount: gallery.length, file });
      }
    }catch(e){
      console.warn("Failed", page, e.message);
    }
  }
  const logPath = path.join(LOG_DIR, `scrape-${new Date().toISOString().slice(0,10)}.json`);
  fs.writeFileSync(logPath, JSON.stringify({ pages: scraped }, null, 2), "utf-8");
  console.log("Wrote", scraped.length, "case study files.");
  console.log("Log:", logPath);
}

await generate();
