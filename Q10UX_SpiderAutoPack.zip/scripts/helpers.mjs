// scripts/helpers.mjs
// ESM utilities shared by spider/fixers. Node >=18
import fs from "node:fs";
import path from "node:path";
import { JSDOM } from "jsdom";

export function ensureDir(p){ fs.mkdirSync(p, { recursive: true }); }
export function readJSON(p, fallback=null){
  try { return JSON.parse(fs.readFileSync(p, "utf-8")); } catch { return fallback; }
}
export function writeJSON(p, data){
  ensureDir(path.dirname(p));
  fs.writeFileSync(p, JSON.stringify(data, null, 2), "utf-8");
}
export function readText(p, fallback=""){
  try { return fs.readFileSync(p, "utf-8"); } catch { return fallback; }
}
export function writeText(p, data){
  ensureDir(path.dirname(p));
  fs.writeFileSync(p, data, "utf-8");
}

export function slugify(s){
  return (s||"")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export async function fetchHtml(url){
  const res = await fetch(url, { headers: { "User-Agent": "Q10UX-Spider/1.0" } });
  if(!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return await res.text();
}

export function parseHtml(html){
  return new JSDOM(html).window.document;
}

export function absoluteUrl(href, base){
  try { return new URL(href, base).toString(); } catch { return null; }
}

export function extractSummary(doc){
  const meta = doc.querySelector('meta[name="description"]');
  if(meta?.content) return meta.content.trim();
  const p = doc.querySelector("main p, article p, .content p");
  return p?.textContent?.trim() || "";
}

// ----- Clean HTML -> Markdown (simple, readable, no inline styles)
export function toMarkdown(root){
  const allowed = new Set(["H1","H2","H3","H4","P","UL","OL","LI","A","STRONG","B","EM","I","BLOCKQUOTE","HR","CODE","PRE","BR"]);
  function md(node){
    if(node.nodeType === 3){ return node.nodeValue.replace(/\s+/g, " ").trim(); }
    if(node.nodeType !== 1) return "";
    const tag = node.tagName;
    if(tag === "BR") return "  \n";
    if(tag === "STRONG" || tag === "B") return `**${children(node)}**`;
    if(tag === "EM" || tag === "I") return `*${children(node)}*`;
    if(tag === "A"){
      const href = node.getAttribute("href") || "#";
      const text = children(node) || href;
      return `[${text}](${href})`;
    }
    if(tag === "H1") return `# ${children(node)}\n\n`;
    if(tag === "H2") return `## ${children(node)}\n\n`;
    if(tag === "H3") return `### ${children(node)}\n\n`;
    if(tag === "H4") return `#### ${children(node)}\n\n`;
    if(tag === "P")  { const t = children(node); return t ? `${t}\n\n` : ""; }
    if(tag === "BLOCKQUOTE") return `> ${children(node)}\n\n`;
    if(tag === "HR") return `---\n\n`;
    if(tag === "UL"){
      let out = "";
      node.querySelectorAll(":scope > li").forEach(li => { out += `- ${md(li).trim()}\n`; });
      return out ? out + "\n" : "";
    }
    if(tag === "OL"){
      let out = "";
      let i = 1;
      node.querySelectorAll(":scope > li").forEach(li => { out += `${i}. ${md(li).trim()}\n`; i++; });
      return out ? out + "\n" : "";
    }
    if(tag === "LI"){ return children(node); }
    if(tag === "PRE"){
      const code = node.textContent || "";
      return "```\n" + code.replace(/\n+$/,"") + "\n```\n\n";
    }
    if(tag === "CODE"){ return "`" + (node.textContent || "").trim() + "`"; }
    if(tag === "IMG") return "";
    return children(node);
  }
  function children(node){
    let s = "";
    node.childNodes.forEach(n => { s += md(n); });
    return s;
  }
  const main = root.querySelector("main, article, .content") || root.body;
  main.querySelectorAll("nav, footer, aside, header, script, style").forEach(el => el.remove());
  const figures = Array.from(main.querySelectorAll("figure"));
  figures.forEach(f => {
    const cap = f.querySelector("figcaption");
    if(cap){
      const p = root.createElement("p");
      p.textContent = cap.textContent;
      f.replaceWith(p);
    }else{
      f.remove();
    }
  });
  let out = "";
  main.childNodes.forEach(n => { out += md(n); });
  out = out.replace(/\n{3,}/g, "\n\n").trim() + "\n";
  return out;
}

export function extractGallery(doc, pageUrl){
  const zone = doc.querySelector("main, article, .content") || doc.body;
  const imgs = Array.from(zone.querySelectorAll("img"));
  const gallery = [];
  for(const img of imgs){
    let src = img.getAttribute("data-src") || img.getAttribute("src") || "";
    if(!src) continue;
    src = absoluteUrl(src, pageUrl);
    if(!src) continue;
    const alt = (img.getAttribute("alt") || "").trim();
    let caption = "";
    const fig = img.closest("figure");
    if(fig){
      const cap = fig.querySelector("figcaption");
      if(cap) caption = cap.textContent.trim();
    }
    gallery.push({ src, alt, caption });
  }
  const seen = new Set(); const dedup = [];
  for(const it of gallery){ if(!seen.has(it.src)){ seen.add(it.src); dedup.push(it); } }
  return dedup;
}

export function parseFrontmatter(text){
  const m = text.match(/^---\n([\s\S]*?)\n---\n?/);
  if(!m) return { front:{}, body:text };
  const body = text.slice(m[0].length);
  const front = {};
  for(const line of m[1].split("\n")){
    const kv = line.match(/^\s*([A-Za-z0-9_-]+)\s*:\s*(.*)\s*$/);
    if(!kv) continue;
    const key = kv[1]; let val = kv[2].trim();
    if(/^".*"$/.test(val) || /^'.*'$/.test(val)) val = val.slice(1,-1);
    front[key]=val;
  }
  return { front, body };
}

export function stringifyFrontmatter(obj){
  const ORDER = ["title","slug","status","summary","tags","client","role","year","layout","thumb","gallery"];
  const seen = new Set();
  const lines = ["---"];
  for(const k of ORDER){
    if(k in obj){ lines.push(`${k}: ${yaml(obj[k])}`); seen.add(k); }
  }
  for(const [k,v] of Object.entries(obj)){
    if(!seen.has(k)) lines.push(`${k}: ${yaml(v)}`);
  }
  lines.push("---\n");
  return lines.join("\n");
}
function yaml(v){
  if(Array.isArray(v)){
    if(v.length && typeof v[0]==="object"){
      return "\n" + v.map(it => {
        const pairs = Object.entries(it).filter(([_,val])=>val!=null && val!=="").map(([k,val]) => `${k}: ${yaml(val)}`).join(", ");
        return `  - { ${pairs} }`;
      }).join("\n");
    }
    return `[${v.map(yaml).join(", ")}]`;
  }
  if(v && typeof v === "object"){
    return "\n" + Object.entries(v).map(([k,val]) => `  ${k}: ${yaml(val)}`).join("\n");
  }
  if(typeof v === "string"){
    if(v === "" || /[:{}\[\],#\n]/.test(v) || /^\d/.test(v) || /\s/.test(v)) return `"${v.replace(/"/g,'\\"')}"`;
    return v;
  }
  if(v == null) return '""';
  return String(v);
}
