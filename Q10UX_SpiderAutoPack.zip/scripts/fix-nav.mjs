// scripts/fix-nav.mjs
import fs from "node:fs";
import path from "node:path";
import { parseFrontmatter, ensureDir } from "./helpers.mjs";

const CASE_DIR = "src/pages/case-studies";
const COMP_DIR = "src/components";
const OUT_COMP = path.join(COMP_DIR, "CaseStudiesDropdown.astro");

function listCases(){
  if(!fs.existsSync(CASE_DIR)) return [];
  const files = fs.readdirSync(CASE_DIR).filter(f => /\.(md|mdx)$/.test(f));
  const items = [];
  for(const f of files){
    const p = path.join(CASE_DIR, f);
    const txt = fs.readFileSync(p, "utf-8");
    const { front } = parseFrontmatter(txt);
    const slug = front.slug || f.replace(/\.(md|mdx)$/,"");
    const title = front.title || slug;
    const status = front.status || "draft";
    items.push({ slug, title, status });
  }
  return items.sort((a,b)=>a.title.localeCompare(b.title));
}

function makeDropdown(items){
  return `---
const items = ${JSON.stringify(items)};
const visible = items.filter(i => i.status !== "hidden");
---
<div class="relative group">
  <a href="/case-studies" class="inline-flex items-center gap-1">Case Studies</a>
  <div class="absolute left-0 mt-2 hidden group-hover:block bg-white/95 dark:bg-neutral-900 shadow-lg rounded-xl ring-1 ring-black/10 min-w-[16rem] p-2 backdrop-blur">
    <ul class="max-h-[60vh] overflow-auto">
      {visible.map(i => (
        <li class="px-2 py-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10">
          <a href={"/case-studies/" + i.slug} class="block">{i.title}</a>
        </li>
      ))}
    </ul>
  </div>
</div>
`;
}

function writeComponent(items){
  ensureDir(COMP_DIR);
  fs.writeFileSync(OUT_COMP, makeDropdown(items), "utf-8");
  console.log("Wrote dropdown:", OUT_COMP);
}

const items = listCases();
writeComponent(items);
