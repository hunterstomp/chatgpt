# Q10UX SpiderAutoPack (Clean Mode, Hotlinked Images)

This pack spiders **https://portfolio.q10ux.com** (About + case studies), converts pages to **clean MDX** (no inline styles), creates **gallery frontmatter** with **hotlinked images**, and builds a **Case Studies dropdown**.

## 0) Drop-in
Unzip this at the **repo root** (same folder as your `package.json`).

## 1) Wire the NPM scripts (one time)
```bash
node scripts/apply-package-scripts.mjs
```

This adds:
```json
"scripts": {
  "spider": "node scripts/spider-site.mjs",
  "nav:update": "node scripts/fix-nav.mjs",
  "autoimport": "npm run spider && npm run nav:update && npm run cases:list"
}
```

## 2) Run the importer
```bash
npm run autoimport
```

What it does:
- Crawls `portfolio.q10ux.com` and finds **About/Home + Case Studies**.
- Writes **clean** `.mdx` files to `src/pages/case-studies/` (status: `draft`).
- Generates `src/pages/about.mdx` (if found).
- Builds `src/components/CaseStudiesDropdown.astro` with all discovered items.
- Saves scrape log to `public/assets/scrape/scrape-YYYY-MM-DD.json`.

## 3) Approve / Publish
```bash
npm run approve   # your existing script
```
Use `p` to publish a case study (it will appear in lists).

## 4) Preview
```bash
npm run dev
# open http://localhost:4321/
```

### Notes
- Images remain **hotlinked** to your current site (fidelity preserved).  
  Later you can mirror images locally and update frontmatter if desired.
- The MDX is **clean** and ready for Tailwind theming. No Mobirise artifacts.
- The dropdown component is standalone (`src/components/CaseStudiesDropdown.astro`).  
  Include it in your main nav as needed:
  ```astro
  ---
  import CaseStudiesDropdown from "@/components/CaseStudiesDropdown.astro";
  ---
  <nav class="...">
    <CaseStudiesDropdown />
  </nav>
  ```
