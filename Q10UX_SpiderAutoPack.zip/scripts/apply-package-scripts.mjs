// scripts/apply-package-scripts.mjs
import fs from "node:fs";

const pkgPath = "package.json";
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));

pkg.scripts = pkg.scripts || {};
pkg.scripts["spider"] = pkg.scripts["spider"] || "node scripts/spider-site.mjs";
pkg.scripts["nav:update"] = pkg.scripts["nav:update"] || "node scripts/fix-nav.mjs";
pkg.scripts["autoimport"] = pkg.scripts["autoimport"] || "npm run spider && npm run nav:update && npm run cases:list";

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf-8");
console.log("✅ package.json updated with scripts: spider, nav:update, autoimport");
